﻿using System;
using System.Collections.Generic;
using Excel = Microsoft.Office.Interop.Excel;
using MySql.Data.MySqlClient;

namespace app
{
	class Program
	{
		//public class 
		
		public class Loader
		{
			Excel.Application xl_app = new Excel.Application();
			Excel.Workbook xl_wb;
			Excel.Worksheet xl_sht;
        	Excel.Range xl_rng;	
        	int i, j;
			int count_rows; // кол-во стр
			int num_col; // номер столбца со значениями
			string content;
			
			List <string> lst = new List<string>();
			HashSet<string> ss = new HashSet<string>();
			
			const string path_to_aud_types = @"D:\KNT\TIMETABLE\data\Auditory_types.xlsx";
			const string path_to_disciplines = @"D:\KNT\TIMETABLE\data\Disciplines.xlsx";
			const string path_to_faculties = @"D:\KNT\TIMETABLE\data\Faculties.xlsx";
			const string path_to_departments = @"D:\KNT\TIMETABLE\data\Departments.xlsx";
			const string path_to_teachers = @"D:\KNT\TIMETABLE\data\Teachers.xlsx";
			const string path_to_study_groups = @"D:\KNT\TIMETABLE\data\Study_groups.xlsx";
			const string path_to_auditories = @"D:\KNT\TIMETABLE\data\Auditories.xls";
			
			const string db = "server=localhost;user=root;database=app_db;password=";
			MySqlConnection conn = new MySqlConnection(db);
			MySqlCommand cmd;
			
			public void load_auditory_types()
			{	
				try
				{
					// 0 - ссылки, true - режим ReadOnly
					xl_wb = xl_app.Workbooks.Open(path_to_aud_types, 0, true);					
					xl_sht = (Excel.Worksheet)xl_wb.Worksheets[1]; //get_Item(1);
					xl_rng = xl_sht.UsedRange;					
					count_rows = xl_rng.Rows.Count;

					for(num_col = 1 /*A*/, i = 1; i <= count_rows; i++)
					{
						content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();
						lst.Add(content);
						Console.WriteLine(content);
					}

					conn.Open();
					foreach (string item in lst)
					{
						try
						{
								const string insert_aud_types = "INSERT INTO auditory_type (auditory_type_name) VALUES (@ITEM)";
								cmd = new MySqlCommand (insert_aud_types, conn);
								cmd.Parameters.AddWithValue("@ITEM", item);
								cmd.ExecuteNonQuery();
								Console.WriteLine(item);		
						}
						catch(Exception ex)
						{
							Console.WriteLine("Ошибка записи из файла: " + path_to_aud_types + ex.Message);
						}
					}
					conn.Close();
					xl_wb.Close(false);
					xl_app.Quit();
				}
				catch(Exception ex)
				{
					Console.WriteLine("Ошибка файла: " + path_to_aud_types + ex.Message);
					Console.ReadKey(true);
				}
			}
			
			public void load_disciplines()
			{
				try
				{
					xl_wb = xl_app.Workbooks.Open(path_to_disciplines, 0, true);
					xl_sht = (Excel.Worksheet)xl_wb.Worksheets[1]; //get_Item(1);
					xl_rng = xl_sht.UsedRange;
					count_rows = xl_rng.Rows.Count;
				
					for(num_col = 7 /*G*/, i = 2; i <= count_rows; i++)
					{
						content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();
						ss.Add(content);
					}
					
					conn.Open();
					foreach (string item in ss)
					{
						try
						{
								const string insert_disciplines = "INSERT INTO discipline (full_name) VALUES (@ITEM)";
								cmd = new MySqlCommand (insert_disciplines, conn);
								cmd.Parameters.AddWithValue("@ITEM", item);
								cmd.ExecuteNonQuery();
								Console.WriteLine(item);		
						}
						catch(Exception ex)
						{ 
							Console.WriteLine("Ошибка записи из файла: " + path_to_disciplines + ex.Message);
						}
					}
					conn.Close();		
					xl_wb.Close(false);
					xl_app.Quit();
					Console.WriteLine("!!!!!!");					
				}
				catch(Exception ex)
				{
					Console.WriteLine("Ошибка файла: " + path_to_disciplines + ex.Message);
					Console.ReadKey(true);
				}				
			}
			
			public void load_faculties()
			{
				try
				{
					xl_wb = xl_app.Workbooks.Open(path_to_faculties, 0, true);
					xl_sht = (Excel.Worksheet)xl_wb.Worksheets[1]; //get_Item(1);
					xl_rng = xl_sht.UsedRange;
					count_rows = xl_rng.Rows.Count - 1;
					
					//Console.WriteLine(count_rows);
					
					string [] codes = new string[count_rows];
					string [] names = new string[count_rows];
					
					for(num_col = 2, i = 2, j = 0; i <= count_rows+1; i++, j++)
					{
						content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();
						names[j] = content;
					}
					
					for(num_col = 4, i = 2, j = 0; i <= count_rows+1; i++, j++)
					{
						content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();
						codes[j] = content;
					}
					
					
					conn.Open();
					for(i = 0; i <count_rows; i++)
					{
						try
						{
							const string insert_faculties = "INSERT INTO faculty (full_name, faculty_code) VALUES (@NAME, @CODE)";
							cmd = new MySqlCommand (insert_faculties, conn);
							cmd.Parameters.AddWithValue("@NAME", names[i]);
							cmd.Parameters.AddWithValue("@CODE", codes[i]);
							cmd.ExecuteNonQuery();
							//Console.WriteLine(names[i] + "\t" + codes[i]);
						}	
						catch(Exception ex)
						{
							Console.WriteLine("Ошибка записи из файла: " + path_to_faculties + ex.Message);
						}	
					}
					conn.Close();
					xl_wb.Close(false);
					xl_app.Quit();
					/*foreach (string st in names)
					{
						Console.WriteLine(st);
					}
					
					foreach (string st in codes)
					{
						Console.WriteLine(st);
					}*/
				}
				catch(Exception ex)
				{
					Console.WriteLine("Ошибка файла: " + path_to_faculties + ex.Message);
					Console.ReadKey(true);
				}
			}
			
			public void load_departments()
			{
				try
				{
					xl_wb = xl_app.Workbooks.Open(path_to_departments, 0, true);
					xl_sht = (Excel.Worksheet)xl_wb.Worksheets[1]; //get_Item(1);
					xl_rng = xl_sht.UsedRange;
					count_rows = xl_rng.Rows.Count;
					
					//Console.WriteLine(count_rows);
					
					string [] full_names = new string[count_rows];
					string [] short_names = new string[count_rows];
					string [] fac_codes = new string[count_rows];
					
					for(num_col = 1 /*A*/, i = 1, j = 0; i <= count_rows; i++, j++)
					{
						content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();
						full_names[j] = content;
					}
					
					for(num_col = 2 /*B*/, i = 1, j = 0; i <= count_rows; i++, j++)
					{
						content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();
						short_names[j] = content;
					}
					
					for(num_col = 3 /*C*/, i = 1, j = 0; i <= count_rows; i++, j++)
					{
						content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();
						fac_codes[j] = content;
					}
					
					conn.Open();
					for (i = 0; i < count_rows; i++)
					{
						try
						{
							const string get_fac_id = "SELECT faculty_id FROM faculty WHERE faculty_code = @CODE";
							cmd = new MySqlCommand (get_fac_id, conn);
							cmd.Parameters.AddWithValue("@CODE", fac_codes[i]);
							cmd.ExecuteNonQuery();
							string result = cmd.ExecuteScalar().ToString();
							int fac_id = Convert.ToInt32(result);
							const string insert_departments = "INSERT INTO department (faculty_id, full_name, short_name) VALUES (@FACULTY_ID, @FULL_NAME, @SHORT_NAME)";
							cmd = new MySqlCommand(insert_departments, conn);
							cmd.Parameters.AddWithValue("@FACULTY_ID", fac_id);
							cmd.Parameters.AddWithValue("@FULL_NAME", full_names[i]);
							cmd.Parameters.AddWithValue("@SHORT_NAME", short_names[i]);
							cmd.ExecuteNonQuery();
							// Console.WriteLine(fac_id + "\t" + full_names[i] + "\t" + short_names[i]);
						}
						catch(Exception ex)
						{
							Console.WriteLine("Ошибка записи из файла: " + i + path_to_departments + ex.Message);
						}
					}
					conn.Close();
					xl_wb.Close(false);
					xl_app.Quit();
				}
				catch(Exception ex)
				{
					Console.WriteLine("Ошибка файла: " + path_to_departments + ex.Message);
					Console.ReadKey(true);
				}
			}
			
			public void load_teachers()
			{
				try
				{
					xl_wb = xl_app.Workbooks.Open(path_to_teachers, 0, true);
					xl_sht = (Excel.Worksheet)xl_wb.Worksheets[1]; //get_Item(1);
					xl_rng = xl_sht.UsedRange;
					count_rows = xl_rng.Rows.Count - 7;
					Console.WriteLine(count_rows);
					
					string [] department_names = new string[count_rows];
					string [] names = new string[count_rows];
					string [] sex = new string[count_rows];
					string [] posts = new string[count_rows];
					string [] statuses = new string[count_rows];
					
					//A
					for(num_col = 1, i = 8, j = 0; i <= count_rows+7; i++, j++)
					{
						if ((xl_rng.Cells[i,num_col] as Excel.Range).Value2 == null)
						{
							content = "";
						}
						else
						{
							content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();	
						}
						department_names[j] = content;
						//Console.WriteLine(department_names[j]);
					}
						
					//J
					for(num_col = 10, i = 8, j = 0; i <= count_rows+7; i++, j++)
					{
						if ((xl_rng.Cells[i,num_col] as Excel.Range).Value2 == null)
						{
							content = "";
						}
						else
						{
							content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();	
						}
						names[j] = content;
						//Console.WriteLine(names[j]);
					}
					
					//K
					for(num_col = 11, i = 8, j = 0; i <= count_rows+7; i++, j++)
					{
						if ((xl_rng.Cells[i,num_col] as Excel.Range).Value2 == null)
						{
							content = "";
						}
						else
						{
							content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();	
						}
						sex[j] = content;
						//Console.WriteLine(sex[j]);
					}
					
					//L
					for(num_col = 12, i = 8, j = 0; i <= count_rows+7; i++, j++)
					{
						if ((xl_rng.Cells[i,num_col] as Excel.Range).Value2 == null)
						{
							content = "";
						}
						else
						{
							content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();	
						}
						posts[j] = content;
						//Console.WriteLine(posts[j]);
					}
					
					//M
					for(num_col = 13, i = 8, j = 0; i <= count_rows+7; i++, j++)
					{
						if ((xl_rng.Cells[i,num_col] as Excel.Range).Value2 == null)
						{
							content = "";
						}
						else
						{
							content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();	
						}
						statuses[j] = content;
					}					
					
					//int errror = 0, bug = 0;
					conn.Open();
					for(i =0 ; i < count_rows; i++)
					{
						try
						{
							const string get_dep_id = "SELECT department_id FROM department WHERE full_name = @DEPARTMENT";
							cmd = new MySqlCommand (get_dep_id, conn);
							cmd.Parameters.AddWithValue("@DEPARTMENT", department_names[i]);
							cmd.ExecuteNonQuery();
							string result = cmd.ExecuteScalar().ToString();
							int dep_id = Convert.ToInt32(result);
							const string insert_teachers = "INSERT INTO teacher (department_id, full_name, sex, post, status) VALUES (@DEP_ID, @FULL_NAME, @SEX, @POST, @STATUS)";
							
							cmd = new MySqlCommand(insert_teachers, conn);
							cmd.Parameters.AddWithValue("@DEP_ID", dep_id);
							cmd.Parameters.AddWithValue("@FULL_NAME", names[i]);
							cmd.Parameters.AddWithValue("@SEX", sex[i]);
							cmd.Parameters.AddWithValue("@POST", posts[i]);
							cmd.Parameters.AddWithValue("@STATUS", statuses[i]);
							cmd.ExecuteNonQuery();
							//Console.WriteLine(dep_id);	
						}
						catch(Exception ex)
						{
							//errror++;
							Console.WriteLine("Ошибка записи из файла: " + path_to_teachers + ex.Message);
							//bug = i;
						}
					}
					//Console.WriteLine(errror);
					//Console.WriteLine(bug);
					conn.Close();
					xl_wb.Close(false);
					xl_app.Quit();
					/*for(i =0 ; i  < 1183; i++)
						Console.WriteLine(department_names[i] + " " + names[i] + " " + sex[i] + " " + posts[i] + " " + statuses[i]);
				*/
				
					// запись в бд +
						// для всех считываний из файлов предусмотреть возможность пустой ячейки:

							// например: 
							// возможна ошибка если попадется пустая ячейка: content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();
							
							// теперь норм!
							/* if ((xl_rng.Cells[i,num_col] as Excel.Range).Value2 == null)
						{
							content = "";
						}
						else
						{
							content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();	
						}*/	
				}
				catch(Exception ex)
				{
					Console.WriteLine("Ошибка файла: " + path_to_teachers + ex.Message);
					Console.ReadKey(true);
				}
			}
			
			public void load_study_groups()
			{
				try
				{
					xl_wb = xl_app.Workbooks.Open(path_to_study_groups, 0, true);
					xl_sht = (Excel.Worksheet)xl_wb.Worksheets[1]; //get_Item(1);
					xl_rng = xl_sht.UsedRange;
					count_rows = xl_rng.Rows.Count;
					Console.WriteLine(count_rows);
					
					string [] dep_short_names = new string[count_rows];
					string [] names = new string[count_rows];
					string [] numbers  = new string[count_rows];
					
					/*A*/
					for(num_col = 1, i = 1, j = 0; i <= count_rows; i++, j++)
					{
						if ((xl_rng.Cells[i,num_col] as Excel.Range).Value2 == null)
						{
							content = "";
						}
						else
						{
							content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();	
						}
						dep_short_names[j] = content;
						//Console.WriteLine(dep_short_names[j]);
					}
					
					/*B*/
					for(num_col = 2, i = 1, j = 0; i <= count_rows; i++, j++)
					{
						if ((xl_rng.Cells[i,num_col] as Excel.Range).Value2 == null)
						{
							content = "";
						}
						else
						{
							content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();	
						}
						names[j] = content;
						//Console.WriteLine(names[j]);
					}
					
					/*C*/
					for(num_col = 3, i = 1, j = 0; i <= count_rows; i++, j++)
					{
						if ((xl_rng.Cells[i,num_col] as Excel.Range).Value2 == null)
						{
							content = "";
						}
						else
						{
							content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();	
						}
						numbers[j] = content;
						//Console.WriteLine(numbers[j]);
					}
					
					conn.Open();
					for(i =0; i <count_rows; i++)
					{
						try
						{
							const string get_dep_id = "SELECT department_id FROM department WHERE short_name = @DEPARTMENT";
							cmd = new MySqlCommand (get_dep_id, conn);
							cmd.Parameters.AddWithValue("@DEPARTMENT", dep_short_names[i]);
							cmd.ExecuteNonQuery();
							string result = cmd.ExecuteScalar().ToString();
							int dep_id = Convert.ToInt32(result);
							
							const string insert_study_groups = "INSERT INTO study_group (department_id, full_name, count_of_students) VALUES (@DEP_ID, @FULL_NAME, @COUNT)";
							cmd = new MySqlCommand(insert_study_groups, conn);
							cmd.Parameters.AddWithValue("@DEP_ID", dep_id);
							cmd.Parameters.AddWithValue("@FULL_NAME", names[i]);
							cmd.Parameters.AddWithValue("@COUNT", Convert.ToInt32(numbers[i]));
							cmd.ExecuteNonQuery();
							//Console.WriteLine(dep_id);
						}
						catch(Exception ex)
						{
							Console.WriteLine("Ошибка записи из файла: " + path_to_teachers + ex.Message);
						}
					}
					conn.Close();
					xl_wb.Close(false);
					xl_app.Quit();
					
				}
				catch(Exception ex)
				{
					Console.WriteLine("Ошибка файла: " + path_to_study_groups + ex.Message);
					Console.ReadKey(true);
				}
			}
			
			public void load_auditories()
			{
				try
				{
					xl_wb = xl_app.Workbooks.Open(path_to_auditories, 0, true);
					xl_sht = (Excel.Worksheet)xl_wb.Worksheets[1]; //get_Item(1);
					xl_rng = xl_sht.UsedRange;
					count_rows = xl_rng.Rows.Count;
					//Console.WriteLine(count_rows);
					
					string [] aud_names = new string[count_rows-1];
					string [] aud_types = new string[count_rows-1];
					string [] dep_names = new string[count_rows-1];
					
					bool [] not_used_aud = new bool[count_rows-1];
					int [] counts_of_places = new int[count_rows-1];
					
					
					/*E*/
					for(num_col = 5, i = 2, j = 0; i <= count_rows; i++, j++)
					{
						if ((xl_rng.Cells[i,num_col] as Excel.Range).Value2 == null)
						{
							content = "";
						}
						else
						{
							content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();	
						}
						aud_names[j] = content;
						//Console.WriteLine(aud_names[j]);		
					}
					
					/*H*/
					for(num_col = 8, i = 2, j = 0; i <= count_rows; i++, j++)
					{
						if ((xl_rng.Cells[i,num_col] as Excel.Range).Value2 == null)
						{
							content = "";
						}
						else
						{
							content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();	
						}
						aud_types[j] = content;
						//Console.WriteLine(aud_types[j]);		
					}
					
					/*I*/
					for(num_col = 9, i = 2, j = 0; i <= count_rows; i++, j++)
					{
						if ((xl_rng.Cells[i,num_col] as Excel.Range).Value2 == null)
						{
							content = "";
						}
						else
						{
							content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();	
						}
						dep_names[j] = content;		
					}
					
					/*J*/
					for(num_col = 10, i = 2, j = 0; i <= count_rows; i++, j++)
					{
						if ((xl_rng.Cells[i,num_col] as Excel.Range).Value2 == null)
						{
							content = "";
							not_used_aud[j] = false;
						}
						else
						{
							content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();
							not_used_aud[j] = true;
						}
						
						//Console.WriteLine(not_used_aud[j].Length);		
					}
					
					/*G*/
					for(num_col = 7, i = 2, j = 0; i <= count_rows; i++, j++)
					{
						if ((xl_rng.Cells[i,num_col] as Excel.Range).Value2 == null)
						{
							counts_of_places[j] = 0;
						}
						else
						{
							content = ((xl_rng.Cells[i,num_col] as Excel.Range).Value2).ToString();
							counts_of_places[j] = Convert.ToInt32(content);	
						}		
					}
					
					//int errors = 0;
					/*30*/
					
					conn.Open();
					for(i = 0; i <count_rows-1; i++)
					{
						try
						{
							const string get_aud_type_id = "SELECT auditory_type_id FROM auditory_type WHERE auditory_type_name = @AUD_TYPE";
							cmd = new MySqlCommand (get_aud_type_id, conn);
							cmd.Parameters.AddWithValue("@AUD_TYPE", aud_types[i]);
							cmd.ExecuteNonQuery();
							string result = cmd.ExecuteScalar().ToString();
							int aud_type_id = Convert.ToInt32(result);
							
							const string get_dep_id = "SELECT department_id FROM department WHERE full_name = @DEPARTMENT";
							cmd = new MySqlCommand(get_dep_id, conn);
							cmd.Parameters.AddWithValue("@DEPARTMENT", dep_names[i]);
							cmd.ExecuteNonQuery();
							string result2 = cmd.ExecuteScalar().ToString();
							int dep_id = Convert.ToInt32(result2);
							
							
							const string insert_auditories = "INSERT INTO auditory (department_id, auditory_name, not_used, type_auditory, count_of_places)" +
								"VALUES (@DEP_ID, @AUD_NAME, @NOT_USED, @TYPE_AUD, @COUNT)";
							cmd = new MySqlCommand(insert_auditories, conn);
							cmd.Parameters.AddWithValue("@DEP_ID", dep_id);
							cmd.Parameters.AddWithValue("@AUD_NAME", aud_names[i]);
							cmd.Parameters.AddWithValue("@NOT_USED", not_used_aud[i]);
							cmd.Parameters.AddWithValue("@TYPE_AUD", aud_type_id);
							cmd.Parameters.AddWithValue("@COUNT", counts_of_places[i]);
							cmd.ExecuteNonQuery();
							Console.WriteLine(aud_names[i]+ "\t" + counts_of_places[i] + "\t" + not_used_aud[i] + "\t" + aud_type_id + "\t" + dep_id);
						}
						catch(Exception ex)
						{
						//	lst.Add(i.ToString());
						//	++ errors;
							Console.WriteLine("Ошибка записи из файла: " + path_to_auditories + ex.Message);
						}
					}
					conn.Close();
					/*Console.WriteLine(errors);
					Console.WriteLine();
					foreach (string str in lst)
					{
						Console.WriteLine(str);
					}*/
					
					xl_wb.Close(false);
					xl_app.Quit();
					
					/*for (i = 0; i<20; i++)
					{
						Console.WriteLine(aud_names[i]+ "\t" + counts_of_places[i] + "\t" + not_used_aud[i] + "\t" + aud_type_id[i]);
					}*/
				}
				catch(Exception ex)
				{
					Console.WriteLine("Ошибка файла: " + path_to_auditories + ex.Message);
					Console.ReadKey(true);
				}
			}
			
		}
		
		public static void Main(string[] args)
		{
			Loader l = new Loader();
			
			/*l.load_auditory_types();
			l.load_disciplines();
			l.load_faculties();
			l.load_departments();
			l.load_teachers();
			l.load_study_groups();
			 */
			
			l.load_auditories();
			Console.ReadKey(true);
		}
	}
}